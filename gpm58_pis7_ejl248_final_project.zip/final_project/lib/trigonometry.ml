let sin = Float.sin
let cos = Float.cos
let tan = Float.tan
let acos = Float.acos
let asin = Float.asin
let atan = Float.atan
