# Installation/Run Instructions
1. `cd` into the `final_project/bin` directory.
2. Run `dune build main.exe`.
3. Run `cd ..` to return to the toplevel directory.
4. Run `dune exec ./bin/main.exe` to run the main program.