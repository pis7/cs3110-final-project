let help_menu (section : string) =
  match section with
  | "plot" -> print_endline "more to come"
  | "eval" -> print_endline "more to come"
  | "settings" -> print_endline "more to come"
  | _ -> print_endline "Enter a valid option: <plot>, <eval>, <settings>"
